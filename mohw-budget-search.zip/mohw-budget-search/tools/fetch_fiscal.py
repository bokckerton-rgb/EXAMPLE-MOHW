# -*- coding: utf-8 -*-
"""
열린재정 API에서 보건복지부 세부사업 예산을 내려받는 프로그램
================================================================

[사용법] 명령 프롬프트(cmd)에서 프로젝트 폴더로 이동한 뒤:

    python tools/fetch_fiscal.py                 ← 2024~2026년 보건복지부 전체
    python tools/fetch_fiscal.py 2025 2026       ← 원하는 연도만

[인증키] 둘 중 하나만 하면 됩니다.
  1) tools 폴더에 api_key.txt 파일을 만들고 인증키 한 줄만 붙여넣기  (추천)
  2) 환경변수 OPENFISCAL_KEY 에 인증키 넣기

[결과]
  cache/fiscal/ExpenditureBudgetInit5_보건복지부_2026.json  ← API 원본 (연도별)
  data/fiscal_mohw.js                                      ← 검색 화면(budget_search.html)이 읽는 파일

추가 설치가 필요 없습니다. (파이썬 기본 기능만 사용)
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta

API_BASE = "https://openapi.openfiscaldata.go.kr"
API_CODE = "ExpenditureBudgetInit5"          # 세부사업 예산편성현황(총액)
OFFICE = "보건복지부"
DEFAULT_YEARS = [2024, 2025, 2026]
PAGE_SIZE = 1000

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(ROOT, "cache", "fiscal")
OUT_JS = os.path.join(ROOT, "data", "fiscal_mohw.js")
KST = timezone(timedelta(hours=9))


def read_key():
    key = os.environ.get("OPENFISCAL_KEY", "").strip()
    if key:
        return key
    path = os.path.join(ROOT, "tools", "api_key.txt")
    if os.path.exists(path):
        with open(path, encoding="utf-8-sig") as f:
            return f.read().strip()
    print("[멈춤] 인증키가 없습니다.")
    print("  tools 폴더에 api_key.txt 파일을 만들고 열린재정 인증키를 붙여넣어 주세요.")
    sys.exit(1)


def find_rows_and_total(obj):
    """열린재정 응답 모양: {API코드: [{"head":[{"list_total_count":N},{"RESULT":{...}}]}, {"row":[...]}]}"""
    rows, total, result = [], None, None

    def walk(o):
        nonlocal rows, total, result
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "row" and isinstance(v, list):
                    rows.extend(v)
                elif k == "list_total_count":
                    total = int(v)
                elif k == "RESULT" and isinstance(v, dict):
                    result = v
                else:
                    walk(v)
        elif isinstance(o, list):
            for item in o:
                walk(item)

    walk(obj)
    return rows, total, result


def call_api(key, year, page):
    params = {
        "Key": key, "Type": "json", "pIndex": page, "pSize": PAGE_SIZE,
        "FSCL_YY": year, "OFFC_NM": OFFICE,
    }
    url = f"{API_BASE}/{API_CODE}?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "MOHW-handover/0.1"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_year(key, year):
    all_rows, page, total = [], 1, None
    while True:
        data = call_api(key, year, page)
        rows, t, result = find_rows_and_total(data)
        if total is None:
            total = t
        if not rows:
            if result and result.get("CODE") not in (None, "INFO-000"):
                print(f"   - {year}년: {result.get('MESSAGE', result)}")
            break
        all_rows.extend(rows)
        print(f"   - {year}년 {page}쪽: {len(rows)}건 (누적 {len(all_rows)}/{total or '?'})")
        if total is not None and len(all_rows) >= total:
            break
        page += 1
        time.sleep(0.3)  # 서버에 부담 주지 않도록 잠깐 쉼
    return all_rows


def main():
    years = [int(a) for a in sys.argv[1:]] or DEFAULT_YEARS
    key = read_key()
    os.makedirs(CACHE_DIR, exist_ok=True)
    observed_at = datetime.now(KST).isoformat(timespec="seconds")

    combined, got_years = [], []
    for y in years:
        print(f"● {y}년 {OFFICE} 예산 내려받는 중...")
        try:
            rows = fetch_year(key, y)
        except Exception as e:  # 인터넷·인증키 문제
            print(f"   [실패] {y}년: {e}")
            continue
        if not rows:
            print(f"   {y}년 자료 없음 (아직 공개 전일 수 있음)")
            continue
        raw_path = os.path.join(CACHE_DIR, f"{API_CODE}_{OFFICE}_{y}.json")
        with open(raw_path, "w", encoding="utf-8") as f:
            json.dump({"api_code": API_CODE, "params": {"FSCL_YY": y, "OFFC_NM": OFFICE},
                       "observed_at": observed_at, "rows": rows}, f, ensure_ascii=False, indent=1)
        combined.extend(rows)
        got_years.append(y)

    if not combined:
        print("\n받은 자료가 없어 기존 data/fiscal_mohw.js 를 그대로 둡니다.")
        sys.exit(1)

    out = {
        "source": "열린재정 OpenAPI ExpenditureBudgetInit5 (세부사업 예산편성현황·총액)",
        "document_id": "SRC-OPENFISCAL-API", "api_code": API_CODE, "office": OFFICE,
        "unit": "천원", "observed_at": observed_at, "is_sample": False,
        "years": got_years, "rows": combined,
    }
    with open(OUT_JS, "w", encoding="utf-8") as f:
        f.write("// 자동 생성 파일 - 직접 고치지 마세요 (tools/fetch_fiscal.py가 다시 만듭니다)\n")
        f.write("window.FISCAL_DATA = " + json.dumps(out, ensure_ascii=False, indent=1) + ";\n")
    print(f"\n완료! {got_years}년 총 {len(combined)}건 → data/fiscal_mohw.js")
    print("이제 budget_search.html 을 더블클릭해서 검색해 보세요.")


if __name__ == "__main__":
    main()
