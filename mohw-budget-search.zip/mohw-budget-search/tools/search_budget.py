# -*- coding: utf-8 -*-
"""
담당 사업 예산 검색 + budget_facts.json 저장
=============================================

[검색만]
    python tools/search_budget.py 아동수당
    python tools/search_budget.py 돌봄

[검색 결과를 우리 규격(budget_facts.json)에 저장]
    python tools/search_budget.py 아동수당 --save POL-CHILD-ALLOWANCE

  - 검색어가 세부사업명·단위사업명·프로그램명 어디에든 들어 있으면 찾습니다.
  - 저장 시 금액 단위는 '천원', 출처는 SRC-OPENFISCAL-API, 검증상태는 auto_extracted 로 들어갑니다.
  - 같은 줄을 두 번 저장해도 중복으로 쌓이지 않습니다 (같은 budget_id면 덮어씀).
  - 시행계획 값과 다르면 사람이 review_items 에 기록하세요 (규격 7단계).
"""
import json
import os
import sys
import hashlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_JS = os.path.join(ROOT, "data", "fiscal_mohw.js")
FACTS = os.path.join(ROOT, "data", "budget_facts.json")


def load_data():
    with open(DATA_JS, encoding="utf-8") as f:
        text = f.read()
    start = text.index("{")
    end = text.rindex("}")
    return json.loads(text[start:end + 1])


def norm(s):
    return (s or "").replace(" ", "").replace("·", "").replace("ㆍ", "").lower()


def search(data, keyword):
    k = norm(keyword)
    hits = [r for r in data["rows"]
            if k in norm(r.get("SACTV_NM")) or k in norm(r.get("ACTV_NM")) or k in norm(r.get("PGM_NM"))]
    # 같은 사업(회계+계정+단위+세부)끼리 연도별로 묶기
    groups = {}
    for r in hits:
        key = (r.get("FSCL_NM"), r.get("ACCT_NM"), r.get("ACTV_NM"), r.get("SACTV_NM"))
        groups.setdefault(key, {})[int(r["FSCL_YY"])] = r
    return groups


def eok(thousand_won):
    """천원 → 억원 (소수 첫째 자리)"""
    return f"{thousand_won / 100000:,.1f}억"


def print_groups(groups, years):
    if not groups:
        print("찾은 사업이 없습니다. 띄어쓰기를 빼거나 더 짧은 단어로 검색해 보세요.")
        return
    print(f"찾은 사업 {len(groups)}개  (금액: 국회 확정 기준, 괄호는 정부안)\n")
    for i, ((fscl, acct, actv, sactv), by_year) in enumerate(groups.items(), 1):
        any_row = next(iter(by_year.values()))
        print(f"[{i}] {sactv}")
        print(f"    {any_row.get('SECT_NM')} > {any_row.get('PGM_NM')} > {actv}")
        print(f"    회계: {fscl}{(' / ' + acct) if acct else ''}")
        line = []
        for y in years:
            r = by_year.get(y)
            if r:
                line.append(f"{y}년 {eok(r['Y_YY_DFN_MEDI_KCUR_AMT'])}({eok(r['Y_YY_MEDI_KCUR_AMT'])})")
            else:
                line.append(f"{y}년 -")
        print("    " + " | ".join(line))
        print()


def to_facts(groups, policy_id, data):
    facts = []
    for (fscl, acct, actv, sactv), by_year in groups.items():
        for y, r in sorted(by_year.items()):
            tag = hashlib.md5(f"{fscl}|{acct}|{actv}|{sactv}".encode()).hexdigest()[:6].upper()
            for field, amount_type, short in (("Y_YY_MEDI_KCUR_AMT", "정부안", "GOV"),
                                              ("Y_YY_DFN_MEDI_KCUR_AMT", "본예산", "FIN")):
                facts.append({
                    "budget_id": f"BUD-{policy_id.replace('POL-', '')}-{y}-OF-{short}-{tag}",
                    "policy_id": policy_id,
                    "fiscal_year": y,
                    "account": fscl + (f"({acct})" if acct else ""),
                    "unit_program_code": None,
                    "unit_program_name": actv,
                    "detail_program_code": None,
                    "detail_program_name": sactv,
                    "amount_type": amount_type,
                    "amount": int(r[field]),
                    "unit": "천원",
                    "source_ref": {
                        "document_id": "SRC-OPENFISCAL-API",
                        "locator": f"{data['api_code']} FSCL_YY={y} OFFC_NM={r.get('OFFC_NM')} SACTV_NM={sactv}",
                        "observed_at": data.get("observed_at"),
                    },
                    "validation_status": "auto_extracted",
                })
    return facts


def save_facts(new_facts):
    container, items = None, []
    if os.path.exists(FACTS):
        with open(FACTS, encoding="utf-8") as f:
            container = json.load(f)
        if isinstance(container, list):
            items = container
        else:  # {"budget_facts": [...]} 같은 모양도 지원
            for k, v in container.items():
                if isinstance(v, list):
                    items = v
                    break
            else:
                container["budget_facts"] = items
    else:
        container = items

    by_id = {it.get("budget_id"): idx for idx, it in enumerate(items) if isinstance(it, dict)}
    added = updated = 0
    for fct in new_facts:
        if fct["budget_id"] in by_id:
            items[by_id[fct["budget_id"]]] = fct
            updated += 1
        else:
            items.append(fct)
            added += 1
    with open(FACTS, "w", encoding="utf-8") as f:
        json.dump(container, f, ensure_ascii=False, indent=2)
    print(f"budget_facts.json 저장: 새로 {added}줄, 갱신 {updated}줄")
    print("→ 저장 후 python tools/check_data.py 로 규격 검사를 해 주세요.")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return
    policy_id = None
    if "--save" in args:
        i = args.index("--save")
        policy_id = args[i + 1] if i + 1 < len(args) else None
        args = args[:i] + args[i + 2:]
        if not policy_id or not policy_id.startswith("POL-"):
            print("--save 뒤에는 POL- 로 시작하는 정책 고유번호를 적어 주세요. 예) --save POL-CHILD-ALLOWANCE")
            return
    keyword = " ".join(args)
    data = load_data()
    if data.get("is_sample"):
        print("※ 지금은 시연용 샘플(아동·보육 부문)만 들어 있습니다. 전체 검색은 fetch_fiscal.py 를 먼저 실행하세요.\n")
    years = sorted({int(r["FSCL_YY"]) for r in data["rows"]})
    groups = search(data, keyword)
    print_groups(groups, years)
    if policy_id and groups:
        save_facts(to_facts(groups, policy_id, data))


if __name__ == "__main__":
    main()
